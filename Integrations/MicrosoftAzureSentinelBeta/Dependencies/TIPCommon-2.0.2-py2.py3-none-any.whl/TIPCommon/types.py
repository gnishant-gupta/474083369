from typing import (
    Any,
    Callable,
    Collection,
    Dict,
    List,
    Tuple,
    Type,
    TypeVar,
    Union,
)

from SiemplifyAction import SiemplifyAction
from SiemplifyConnectors import SiemplifyConnectorExecution
from SiemplifyDataModel import DomainEntityInfo
from SiemplifyJob import SiemplifyJob


_T = TypeVar("_T")
_E = TypeVar("_E")
_R = TypeVar("_R")

ChronicleSOAR = Union[SiemplifyAction, SiemplifyConnectorExecution, SiemplifyJob]

Entity = TypeVar("Entity", bound=DomainEntityInfo)

SingleJson = Dict[str, Any]
JSON = Union[SingleJson, List[SingleJson]]
JsonString = TypeVar("JsonString", bound=str)

GeneralFunction = Callable[..., Any]
Contains = Union[_T, Collection[_T], Type[Tuple[_T, ...]], None]

AuthParams = TypeVar("AuthParams")
ApiParams = TypeVar("ApiParams")

Consumer = Callable[[_T], None]
Supplier = Callable[[], _T]
Function = Callable[[_T], _R]
Predicate = Callable[[_T], bool]
UnaryOperator = Callable[[_T], _T]
BiPredicate = Callable[[_T, _E], bool]
BiConsumer = Callable[[_T, _E], None]
BiFunction = Callable[[_T, _E], _R]
BinaryOperator = Callable[[_T, _T], _T]
